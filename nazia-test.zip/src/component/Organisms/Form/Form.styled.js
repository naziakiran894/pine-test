
import { Box } from "@mui/material";
import { styled } from "@mui/system";

const FullForm = styled(Box)({
 height: "374px",
width:" 10px",
borderRadius: "0px",
background:" #FBFBFB",
boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.25)",
})

const SearchBox= styled(Box)({   
})

const Input = styled(Box)({
    marginTop:"50px",
})

export {FullForm, SearchBox, Input}