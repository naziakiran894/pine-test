import React from "react";
import { useState} from 'react'
import Box from "@mui/material/Box";
import shoe from "../../../Images/shoe.png";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import * as SC from "./CartCard.styled";
import { Button, Typography } from "@mui/material";

const CartCard = () => {
  const [value, setValue] = useState(2);
  const [data, setData] = useState(2);
  return (
    <>
      <SC.Carttt>
        <SC.Pack>
          <Typography
            style={{
              height: "23px",
              width: "119px",
              fontWeight: "bold",
              fontWeight: "700",
              fontSize: "20px",
              lineHeight: "23px",
              color: "#000000",
            }}
          >
            Package 1
          </Typography>
          <Typography
            style={{
              fontFamily: "Roboto",
              fontStyle: "normal",
              fontWeight: "400",
              fontSize: "18px",
              lineHeight: "21px",
              color: "#000000}",
            }}
          >
            store Name
          </Typography>
          <SC.shoe>
            <img src={shoe}  alt = "" style={{ height: "80px", width: "80px" }} />
            <Box>
              <Typography
                style={{
                  height: "23px",
                  width: "119px",
                  fontWeight: "500",
                  fontSize: "18px",
                  lineHeight: "21px",
                  color: "#000000",
                }}
              >
                Product 1
              </Typography>
              <Typography
                style={{
                  height: "23px",
                  width: "219px",
                  fontWeight: "300",
                  fontSize: "18px",
                  lineHeight: "21px",
                  color: "#000000",
                }}
              >
                22RS*2 = 44RS
              </Typography>
            </Box>
          </SC.shoe>
          <SC.shoe>
            <img src={shoe} alt="" style={{ height: "80px", width: "80px" }} />
            <Box>
              <Typography
                style={{
                  height: "23px",
                  width: "119px",
                  fontWeight: "500",
                  fontSize: "18px",
                  lineHeight: "21px",
                  color: "#000000",
                }}
              >
                Product 1
              </Typography>
              <Typography
                style={{
                  height: "23px",
                  width: "219px",
                  fontWeight: "300",
                  fontSize: "18px",
                  lineHeight: "21px",
                  color: "#000000",
                }}
              >
                22RS*2 = 44RS
              </Typography>
            </Box>
          </SC.shoe>
        </SC.Pack>

        <Box>
          <SC.Incre>
            <Box onClick={() =>setValue(value+1)}
              style={{
                borderRadius: "50%",
                border: "1px solid black",
                height: "16px",
                width: "16px",
                textAlign: "center",
                cursor:"pointer"
              }}
            >
              +
            </Box>
            {value}
            <Box onClick={() =>setValue(value-1)}
              style={{
                borderRadius: "50%",
                border: "1px solid black",
                height: "16px",
                width: "16px",
                textAlign: "center",
                cursor:"pointer"
              }}
            >
              -
            </Box>
          </SC.Incre>
          <Box>
            <DeleteOutlineIcon style={{ margin: "15px", color: "rgba(255, 1, 1, 0.59)" }} />
          </Box>

          <Box>
            <SC.Incre>
              <Box onClick={() =>setData(data+1)}
              
                style={{
                  borderRadius: "50%",
                  border: "1px solid black",
                  height: "16px",
                  width: "16px",
                  textAlign: "center",
                  cursor:"pointer"
                  
                }}
              >
                +
              </Box>
              {data}
              <Box onClick={() =>setData(data-1)}
                style={{
                  borderRadius: "50%",
                  border: "1px solid black",
                  height: "16px",
                  width: "16px",
                  textAlign: "center",
                  cursor:"pointer"
                }}
              >
                -
              </Box>
            </SC.Incre>
            <Box>
              <DeleteOutlineIcon style={{ margin: "15px",  color: "rgba(255, 1, 1, 0.59)" }} />
            </Box>
          </Box>
        </Box>
      </SC.Carttt>
    </>
  );
};

export default CartCard;
