import React from "react";
import Box from "@mui/material/Box";
import * as SC from "./Card.styled";
import { Button, Typography } from "@mui/material";
import Model from "../../Atoms /Model/Model";
import Popup from "../../Atoms /Popup/Popup";

const Card = ({ data }) => {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  return (
    <>
      <Box onClick={handleOpen} sx={{ maxWidth: "288px" }}>
        <img
          width="100%"
          height="291px"
          style={{ borderRadius: "5px" }}
          src={data.thumbnail}
          alt="img"
        />
        <Typography
          mt="17px"
          mb="20px"
          color="#000000"
          sx={{ fontWeight: 500, fontSize: "18px" }}
        >
          {data.title}
        </Typography>
        <Box display="flex" justifyContent="space-between">
          <Typography>{data.price}</Typography>
          <Button>Add to cart</Button>
        </Box>
      </Box>
      <Model open={open} handleClose={handleClose}>
        <Popup data={data} />
      </Model>

      {/* </Box> */}
    </>
  );
};

export default Card;
