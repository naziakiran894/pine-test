import React from 'react'




const Stores = () => {
  return (
    <div>setCategories

    </div>
  )
}

export default Stores